Yunjae Jo
yj6487
07/26/2023

GoFish: The game starts with 2 decks one to decide what player would start and another to play the game. First the players draw a card from the first deck and the player with a lower card starts first. Next, since two players play they both get 7 cards from the starting deck that is shuffled. The players take turn asking the other player if they have a card but the card that a player is asking must be in the hand of the asking player. When the other player has the card that has the same rank all of the card goes to the asking player. If not the other players says go fish and the asking player draws a card from the deck. The players at the end of their turn can book a pair of the card that has the same rank. The game continues until all 26 booking pairs have been made and the player with the larger number of booking pairs win.
- 
How to run:
1. Unzip the files
2. Copy the files inside the Linux directory that you have created
3. Check if all the files have been copied into the directory
4. "cd" into the directory
5. Type in "make"
6. Type in ll to check the highlighted word
7. Type in ./highlighted word
Potential issues
The deck might not be shuffled properly resulting in a unusual outcome.