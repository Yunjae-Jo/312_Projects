#include <iostream>
#include <cstdlib>
#include "card.h"
#include "player.h"
#include "deck.h"
#include <fstream>
using namespace std;

void dealHand(Deck &d, Player &p, int numCards);

int main(){
    ofstream logFile("gofish_results.txt");
    int numCards = 7;
    bool turn;
    bool firstSecond;
    Card emptyDrawCard;
    Card joeGuess;
    Card janeGuess;
    Player p1("Joe");
    Player p2("Jane");
    Deck deckForStart;
    Deck deckForGame;
    deckForStart.shuffle();
    deckForGame.shuffle();
    Card initJoeCard = deckForStart.dealCard();
    Card initJaneCard = deckForStart.dealCard();
    logFile << "Joe draws the " << initJoeCard.rankString(initJoeCard.getRank()) << "." << endl;
    logFile << "Jane draws the " << initJaneCard.rankString(initJaneCard.getRank()) << "." << endl;
    if(initJoeCard.getRank() < initJaneCard.getRank()){
        firstSecond = true;
        logFile << "Joe starts first!" << endl;
    }
    else if(initJoeCard.getRank() > initJaneCard.getRank()){
        firstSecond = false;
        logFile << "Jane starts first!" << endl;
    }
    else{
        logFile << "Both players drew cards with the same rank. Drawing again..." << endl;
        while(initJoeCard.getRank() == initJaneCard.getRank()){
            initJoeCard = deckForStart.dealCard();
            initJaneCard = deckForStart.dealCard();
            logFile << "Joe draws the " << initJoeCard.rankString(initJoeCard.getRank()) << "." << endl;
            logFile << "Jane draws the " << initJaneCard.rankString(initJaneCard.getRank()) << "." << endl;
        }
        if(initJoeCard.getRank() < initJaneCard.getRank()){
            firstSecond = true;
            logFile << "Joe starts first!" << endl;
        }
        else{
            firstSecond = false;
            logFile << "Jane starts first!" << endl;
        }
    }
    dealHand(deckForGame, p1, numCards);
    dealHand(deckForGame, p2, numCards);

    logFile << "Initial hands of both players:" << endl;
    logFile << p1.getName() <<"'s deck: " << p1.showHand() << endl;
    logFile << p2.getName() <<"'s deck: " << p2.showHand() << endl;
    while((p1.getBookSize() + p2.getBookSize() < 26)) {
        //player 1's turn
        logFile << endl;
        if(firstSecond == true){
            logFile << p1.getName() << "'s turn" << endl;
            turn = true;
            while (turn == true){
                if(p1.getHandSize() != 0){
                    joeGuess = p1.chooseCardFromHand();
                    logFile << p1.getName() << ": Do you have a " << joeGuess.rankString(joeGuess.getRank()) << "?"
                         << endl;
                    bool guessCorrect = false;
                    while (p2.sameRankInHand(joeGuess) == true) {
                        Card janeCard = p2.removeCardFromHand(joeGuess);
                        p1.addCard(janeCard);
                        logFile << p2.getName() << ": Yes. I have a " << janeCard.rankString(janeCard.getRank()) << "."
                             << endl;
                        logFile << p1.getName() << " takes the " << janeCard.rankString(janeCard.getRank()) << "." << endl;
                        guessCorrect = true;
                    }
                    if (guessCorrect == false) {
                        logFile << p2.getName() << ": Go Fish" << endl;
                        if(deckForGame.size() != 0){
                            Card drawNewCard;
                            do{
                                drawNewCard = deckForGame.dealCard();
                                p1.addCard(drawNewCard);
                            } while(drawNewCard.getRank() == joeGuess.getRank());
                            logFile << p1.getName() << " draws the " << drawNewCard.rankString(drawNewCard.getRank())<< "." << endl;
                        }
                        else{
                            logFile << "No more card in deck" << endl;
                        }
                    }
                    turn = guessCorrect;
                }
                else{
                    if(deckForGame.size() != 0){
                        logFile << "No card in hand, draw a card." << endl;
                        emptyDrawCard = deckForGame.dealCard();
                        p1.addCard(emptyDrawCard);
                        turn = false;
                    }
                    else{
                        logFile << "No more card in deck" << endl;
                        turn = false;
                    }
                }
            }
            Card c1, c2;
            while (p1.checkHandForPair(c1, c2)) {
                p1.checkHandForPair(c1, c2);
                p1.bookCards(c1, c2);
                logFile << p1.getName() << " books the " << c1.rankString(c1.getRank()) << " pair." << endl;
            }
            logFile << p1.getName() << "'s deck: " << p1.showHand() << endl;
            logFile << p1.getName() << "'s number of booked pairs: " << p1.getBookSize() << endl;
            logFile << p2.getName() << "'s deck: " << p2.showHand() << endl;
            logFile << p2.getName() << "'s number of booked pairs: " << p2.getBookSize() << endl;
            firstSecond = false;
            logFile << endl;
        }

        //player 2's turn
        if(firstSecond == false){
            logFile << p2.getName() << "'s turn" << endl;
            turn = true;
            while (turn == true){
                if(p2.getHandSize() != 0) {
                    janeGuess = p2.chooseCardFromHand();
                    logFile << p2.getName() << ": Do you have a " << janeGuess.rankString(janeGuess.getRank()) << "?"
                         << endl;
                    bool guessCorrect = false;
                    while (p1.sameRankInHand(janeGuess) == true) {
                        Card janeCard = p1.removeCardFromHand(janeGuess);
                        p2.addCard(janeCard);
                        logFile << p1.getName() << ": Yes. I have a " << janeCard.rankString(janeCard.getRank()) << "."
                             << endl;
                        logFile << p2.getName() << " takes the " << janeCard.rankString(janeCard.getRank()) << "." << endl;
                        guessCorrect = true;
                    }
                    if (guessCorrect == false) {
                        logFile << p1.getName() << ": Go Fish" << endl;
                        if(deckForGame.size() != 0){
                            Card drawNewCard;
                            do{
                                drawNewCard = deckForGame.dealCard();
                                p2.addCard(drawNewCard);
                            } while(drawNewCard.getRank() == joeGuess.getRank());
                            logFile << p2.getName() << " draws the " << drawNewCard.rankString(drawNewCard.getRank())<< "." << endl;
                        }
                        else{
                            logFile << "No more card in deck" << endl;
                        }
                    }
                    turn = guessCorrect;
                }
                else{
                    if(deckForGame.size() != 0){
                        logFile << "No card in hand, draw a card." << endl;
                        emptyDrawCard = deckForGame.dealCard();
                        p2.addCard(emptyDrawCard);
                        turn = false;
                    }
                    else{
                        logFile << "No more card in deck" << endl;
                        turn = false;
                    }
                }
            }
            Card c3, c4;
            while (p2.checkHandForPair(c3, c4)) {
                p2.checkHandForPair(c3, c4);
                p2.bookCards(c3, c4);
                logFile << p2.getName() << " books the " << c3.rankString(c3.getRank()) << " pair." << endl;
            }
            logFile << p1.getName() << "'s deck: " << p1.showHand() << endl;
            logFile << p1.getName() << "'s number of booked pairs: " << p1.getBookSize() << endl;
            logFile << p2.getName() << "'s deck: " << p2.showHand() << endl;
            logFile << p2.getName() << "'s number of booked pairs: " << p2.getBookSize() << endl;
            firstSecond = true;
        }
    }
    logFile << endl;
    logFile << p1.getName() << "'s number of booked pairs: " << p1.getBookSize() << endl;
    logFile << "Booked pairs: " << p1.showBooks() << endl;
    logFile << p2.getName() << "'s number of booked pairs: " << p2.getBookSize() << endl;
    logFile << "Booked pairs: " << p2.showBooks() << endl;
    if(p1.getBookSize() > p2.getBookSize()){
        logFile << p1.getName() << " wins!!!" << endl;
    }
    else if(p2.getBookSize() > p1.getBookSize()){
        logFile << p2.getName() << " wins!!!" << endl;
    }
    else{
        logFile << "Tie!!" << endl;
    }
    logFile.close();
    return EXIT_SUCCESS;
}


void dealHand(Deck &d, Player &p, int numCards){
   for (int i=0; i < numCards; i++)
      p.addCard(d.dealCard());
}