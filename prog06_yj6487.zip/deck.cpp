//
// Created by yunja on 7/23/2023.
//
#include "deck.h"
#include <cstdlib>
#include <ctime>

Deck::Deck() : myIndex(0){
    int index = 0;
    int rank;
    for (rank = 1; rank <= 13; ++rank){
        for (int suit = 0; suit < 4; ++suit){
            myCards[index++] = Card(rank, static_cast<Card::Suit>(suit));
        }
    }
}
void Deck::shuffle(){
    srand(static_cast<unsigned int>(time(0)));
    int n = myCards.size();
    for(int i = n - 1; i > 0; --i){
        int j = rand() % (i + 1);
        Card temp = myCards[i];
        myCards[i] = myCards[j];
        myCards[j] = temp;
    }
    myIndex = 0;
}
Card Deck::dealCard(){
    if (myIndex < SIZE){
        return myCards[myIndex++];
    }
    return Card();
}
int Deck::size() const{
    return SIZE - myIndex;
}