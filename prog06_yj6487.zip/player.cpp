//
// Created by yunja on 7/23/2023.
//
#include "player.h"
#include <sstream>
#include <cstdlib>

Player::Player(){}
void Player::addCard(Card c){
    myHand.push_back(c);
}
void Player::bookCards(Card c1, Card c2){
    vector<Card> newHand;
    for(const auto& card : myHand){
        if(card != c1 && card != c2){
            newHand.push_back(card);
        }
    }
    myHand = move(newHand);
    myBook.push_back(c1);
    myBook.push_back(c2);
}
bool Player::checkHandForBook(Card& c1, Card& c2){
    for(unsigned int i = 0; i < myHand.size(); ++i) {
        for(unsigned int j = i + 1; j < myHand.size(); ++j){
            if(myHand[i].getRank() == myHand[j].getRank()){
                c1 = myHand[i];
                c2 = myHand[j];
                return true;
            }
        }
    }
    return false;
}
bool Player::rankInHand(Card c) const{
    for(const auto& card : myHand){
        if(card.getRank() == c.getRank()){
            return true;
        }
    }
    return false;
}
Card Player::chooseCardFromHand() const{
    if(myHand.empty() == false){
        int randomIndex = rand() % myHand.size();
        return myHand[randomIndex];
    }
    return Card();
}
bool Player::cardInHand(Card c) const{
    for(const auto& card : myHand) {
        if(card == c){
            return true;
        }
    }
    return false;
}
Card Player::removeCardFromHand(Card c){
    if(rankInHand(c)){
        for(unsigned int i = 0; i < myHand.size(); ++i){
            if(myHand[i].getRank() == c.getRank()){
                Card removedCard = myHand[i];
                myHand.erase(myHand.begin() + i);
                return removedCard;
            }
        }
    }
    return Card();
}
string Player::showHand() const {
    string handString;
    for(const auto& card : myHand){
        handString += card.toString() + " ";
    }
    return handString;
}
string Player::showBooks() const{
    string booksString;
    for(const auto& card : myBook){
        booksString += card.toString() + " ";
    }
    return booksString;
}
int Player::getHandSize() const{
    return myHand.size();
}
int Player::getBookSize() const{
    return myBook.size() / 2;
}
bool Player::checkHandForPair(Card& c1, Card& c2){
    return checkHandForBook(c1, c2);
}
bool Player::sameRankInHand(Card c) const{
    for(const auto& card : myHand){
        if(card.getRank() == c.getRank() && card != c){
            return true;
        }
    }
    return false;
}