#include<stdio.h>
#include<stdbool.h>


// CodeCampTester.c -- EE 312 Project 1 -- Tester class

/* Student information for assignment:
 *
 * Name: Yunjae Jo
 * email address: yunjaejo@utexas.edu
 * UTEID: yj6487
 * Section 5 digit ID: 75590
 *
 */

//function prototypes. These will be completed in CodeCamp.c
int hammingDistance(int aList[], int bList[], int len);
int sum3or5Multiples();
bool lastDigit(int num1, int num2);
int reverseInt(int num);
//****************************

int main() {
    // test 1, hammingDistance
    int h1[] = {0, 0, 0, 1, 0, 1, 0, 1, 1};
    int h2[] = {1, 0, 0, 0, 1, 1, 0, 1, 0};
    int expected = 4;
    int actual = hammingDistance(h1, h2, 9);
    printf("Test 1 hamming distance: expected value: %d, actual value: %d\n", expected, actual);

    if(expected == actual)
        printf("passed test 1, hamming distance\n\n");
    else
        printf("**** FAILED **** test 1, hamming distance\n\n");

    // test 2, hamming distance
    int h3[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int h4[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    expected = 0;
    actual = hammingDistance(h3, h4, 10);
    printf("Test 2 hamming distance: expected value: %d, actual value: %d\n", expected, actual);

    if(expected == actual)
        printf("passed test 2, hamming distance\n\n");
    else
        printf("**** FAILED **** test 2, hamming distance\n\n");

    // test 3, hamming distance
    int h5[10000] = {0};
    int h6[10000] = {0};
    expected = 0;
    actual = hammingDistance(h5, h6, 10000);
    printf("Test 3 hamming distance: expected value: %d, actual value: %d\n", expected, actual);

    if(expected == actual)
        printf("passed test 3, hamming distance\n\n");
    else
        printf("**** FAILED **** test 3, hamming distance\n\n");

    // test 4, hamming distance
    int h7[] = {4, 3, 3, 100, 5, -13, 7, 62, 9, -10};
    int h8[] = {3, 96, 3, 100, 5, -13, 9, 62, -7, -8};
    expected = 5;
    actual = hammingDistance(h7, h8, 10);
    printf("Test 4 hamming distance: expected value: %d, actual value: %d\n", expected, actual);

    if(expected == actual)
        printf("passed test 4, hamming distance\n\n");
    else
        printf("**** FAILED **** test 4, hamming distance\n\n");

    // test 5, last digit
    int n1 = 2307;
    int n2 = 7;
    expected = true;
    actual = lastDigit(n1, n2);
    printf("Test 5 last digit: expected value: %d, actual value: %d\n", expected, actual);

    if(expected == actual)
        printf("passed test 5, last digit\n\n");
    else
        printf("**** FAILED **** test 5, last digit\n\n");

    // test 6, last digit
    n1 = -176;
    n2 = 6666;
    expected = true;
    actual = lastDigit(n1, n2);
    printf("Test 6 last digit: expected value: %d, actual value: %d\n", expected, actual);

    if(expected == actual)
        printf("passed test 6, last digit\n\n");
    else
        printf("**** FAILED **** test 6, last digit\n\n");

    // test 7, last digit
    n1 = 25687;
    n2 = 100006;
    expected = false;
    actual = lastDigit(n1, n2);
    printf("Test 7 last digit: expected value: %d, actual value: %d\n", expected, actual);

    if(expected == actual)
        printf("passed test 7, last digit\n\n");
    else
        printf("**** FAILED **** test 7, last digit\n\n");

    // test 8, sum of multiples of 3 or 5
    expected = 233168;
    actual = sum3or5Multiples();
    printf("Test 8 sum of multiples: expected value: %d, actual value: %d\n", expected, actual);

    if(expected == actual)
        printf("passed test 8, sum of multiples of 3 or 5\n\n");
    else
        printf("**** FAILED **** test 8, sum of multiples of 3 or 5\n\n");

    // test 9, reverse int
    n1 = 0;
    expected = 0;
    actual = reverseInt(n1);
    printf("Test 9 reverse int: expected value: %d, actual value: %d\n", expected, actual);

    if(expected == actual)
        printf("passed test 9, reverse int\n\n");
    else
        printf("**** FAILED **** test 9, reverse int\n\n");

    // test 10, reverse int
    n1 = 7;
    expected = 7;
    actual = reverseInt(n1);
    printf("Test 10 reverse int: expected value: %d, actual value: %d\n", expected, actual);

    if(expected == actual)
        printf("passed test 10, reverse int\n\n");
    else
        printf("**** FAILED **** test 10, reverse int\n\n");

    // test 11, reverse int
    n1 = 40000000;
    expected = 4;
    actual = reverseInt(n1);
    printf("Test 11 reverse int: expected value: %d, actual value: %d\n", expected, actual);

    if(expected == actual)
        printf("passed test 11, reverse int\n\n");
    else
        printf("**** FAILED **** test 11, reverse int\n\n");

    // test 12, reverse int
    n1 = 2147483647;
    expected = 0;
    actual = reverseInt(n1);
    printf("Test 12 reverse int: expected value: %d, actual value: %d\n", expected, actual);

    if(expected == actual)
        printf("passed test 12, reverse int\n\n");
    else
        printf("**** FAILED **** test 12, reverse int\n\n");

    // test 13, reverse int
    n1 = 1000000004;
    expected = 0;
    actual = reverseInt(n1);
    printf("Test 13 reverse int: expected value: %d, actual value: %d\n", expected, actual);

    if(expected == actual)
        printf("passed test 13, reverse int\n\n");
    else
        printf("**** FAILED **** test 13, reverse int\n\n");

    // test 14, reverse int
    n1 = -2000000005;
    expected = 0;
    actual = reverseInt(n1);
    printf("Test 14 reverse int: expected value: %d, actual value: %d\n", expected, actual);

    if(expected == actual)
        printf("passed test 14, reverse int\n\n");
    else
        printf("**** FAILED **** test 14, reverse int\n\n");

    // test 15, reverse int
    n1 = 34875;
    expected = 57843;
    actual = reverseInt(n1);
    printf("Test 15 reverse int: expected value: %d, actual value: %d\n", expected, actual);

    if(expected == actual)
        printf("passed test 15, reverse int\n\n");
    else
        printf("**** FAILED **** test 15, reverse int\n");
}
