#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<limits.h>

// CodeCamp.c -- EE 312 Project 1

/* Student information for project:
 *
 * Replace <NAME> with your name.
 *
 * On my honor, Yunjae Jo, this programming project is my own work
 * and I have not provided this code to any other student.
 *
 * Name: Yunjae Jo
 * email address: yunjaejo@utexas.edu
 * UTEID: yj6487
 * Section 5 digit ID: 75590
 *
 */



/* Determine the hamming distance between two int arrays.
   pre: aList != null, bList != null, aList.length == bList.length == len
   post: return hamming distance between the two arrays of ints.
   Neither parameter should be altered by this function.
*/

int hammingDistance(int aList[], int bList[], int len) {
    int i;
    int count = 0;
    /* This for loop runs through the list of aList and bList
       and compares the two value until it reaches the end of the list */
    for(i = 0; i < len; i++){
        if(aList[i] != bList[i]) {
            count++;
        }
    }
    return count;
}

/* Determine if two ints have the same last digit.
   Note that the last digit of 0 is 0 and the last digit of -12 is 2.
   post: return true if num1 and num2 have the same last digit, false otherwise.
*/

bool lastDigit(int num1, int num2) {
    int num1Last;
    int num2Last;
    /* These two if checks if the value is negative */
    if(num1 < 0){
        num1 *= -1;
    }
    if(num2 < 0){
        num2 *= -1;
    }
    /* Modulus 10 is used to find the last digit of the int value */
    num1Last = num1 % 10;
    num2Last = num2 % 10;
    if(num1Last == num2Last){
        return true;
    }
    else{
        return false;
    }
}

/* Determine the sum of the positive integers less than 1000 that are multiples of 3 or 5 (or both).
   post: return the sum of the integers from 1 to 1000 that are multiples of 3 or 5 or both.
*/

int sum3or5Multiples() {
    int finalSum = 0;
    int mul3 = 3;
    int mul5 = 5;
    int mul15 = 15;
    /* This while loop adds up the multiples of 3 */
    while(mul3 < 1000){
        finalSum += mul3;
        mul3 += 3;
    }
    /* This while loop adds up the multiples of 5 */
    while(mul5 < 1000){
        finalSum += mul5;
        mul5 += 5;
    }
    /* Since there is a repeated value added for multiples of 3 and 5 multiples of 15 is subtracted */
    while(mul15 < 1000){
        finalSum -= mul15;
        mul15 += 15;
    }
    return finalSum;
}

/* Reverse the digits of an integer. Return the reversed number if it is in the range of type int, 0 otherwise.
   post: return num with digits reversed if the reverse can be stored as an int, 0 otherwise.
*/

int reverseInt(int num) {
    int reverse = 0;
    int numStore;
    int countNum = 0;
    int tempNum = num;
    int i;
    long long checkLimit = 0;
    /* This while loop checks the size of the int value */
    while(tempNum != 0){
        tempNum /= 10;
        countNum++;
    }
    /* The while loop is used to reverse the value */
    for(i = 0; i < countNum; i++){
        numStore = num % 10;
        checkLimit = (checkLimit * 10) + numStore;
        num /= 10;
    }
    /* The if is to check if the reversed value exceeds the supported number range of int */
    if((checkLimit > 2147483647) || (checkLimit < -2147483648)){
        return 0;
    }
    else{
        reverse = checkLimit;
        return reverse;
    }
}