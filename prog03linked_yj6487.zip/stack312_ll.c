#include "stack312_ll.h"
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
//create stack
void makeStack(Stack312 *sp){
    sp->top = NULL;
}
//check if stack is full
bool isFull(Stack312 s){
    StackNode *newNode = (StackNode*)malloc(sizeof(StackNode));
    if(newNode == NULL){
        return true;
    }
    else{
        free(newNode);
        return false;
    }
}
//check if stack is empty
bool isEmpty(Stack312 s){
    return s.top == NULL;
}
//push into the stack
void push(StackEntry e,Stack312 *sp){
    StackNode* tempNode = (StackNode*)malloc(sizeof(StackNode));
    tempNode->pixel = e;
    tempNode->next = sp->top;
    sp->top = tempNode;
}
//pop out of the stack
StackEntry pop(Stack312 *sp){
    if (isEmpty(*sp)) {
        StackEntry nullEntry;
        return nullEntry;
    }
    else {
        StackNode *tempNode = sp->top;
        StackEntry popped = tempNode->pixel;
        sp->top = tempNode->next;
        free(tempNode);
        return popped;
    }
}
