Yunjae Jo
yj6487
06/30/2023

Flood Fill:
- This program inputs a textfile that contains a rectangular grid that is filled with characters that were assigned with a specific color. By choosing a row and a column on the grid and assigning it to a new color would change the color of all of the same colors next to the specific color that the user picked with the row and column. The output would show the initial grid and ask the user for a row, after typing in the row it would ask the user for the column, after typing in the column it would ask for the color and after all of these processes it would output the updated grid. This program would allow the user to fill in the color until the user types in -1 for either the row or the column. This program uses the linked list sturcture. 
How to run:
1. Unzip the files
2. Copy the files inside the Linux directory that you have created
3. Check if all the files have been copied into the directory(including the textfile)
4. "cd" into the directory
5. Type in "make"
6. Type in ll to check the highlighted word
7. Type in ./highlighted word picture_name.txt
Potential issues
The user must input the correct input for the rows and columns which is an integer and correct input for the colors which is a single character.