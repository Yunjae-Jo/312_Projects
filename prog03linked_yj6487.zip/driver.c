#include <stdio.h>
#include "stack312_ll.h"


char tempPicture[25][25];
int numRows = 0;
int numCols = 0;

//This function reads the text-file given and gets the number of rows and columns
void readingFilePicture(char* fileName) {
    FILE *file = fopen(fileName, "r");
    if (file == NULL) {
        printf("Cannot open file.\n");
        return;
    }
    char colorInPicture;
    int row = 0;
    int column = 0;
    while ((colorInPicture = fgetc(file)) != -1) {
        if (colorInPicture == '\n') {
            column = 0;
            row++;
        }
        else {
            tempPicture[row][column] = colorInPicture;
            column++;
            //Add an if statement since the column becomes 0 after everytime it gets back into the loop
            if (column > numCols) {
                //Get max column
                numCols = column;
            }
        }
    }
    //Get max row
    numRows = row;
    fclose(file);
}
//displays the picture on the screen
void showPictureOnScreen() {
    for (int i = 0; i < numRows; i++)
    {
        for (int j = 0; j < numCols; j++)
        {
            printf("%c", tempPicture[i][j]);
        }
        printf("\n");
    }
}
//This functions checks the surrounding of the current color and fills it with the color that the user assigns
void changeColor(int row, int column, char color) {
    Stack312 stack;
    Pixel pixelCurrent;
    makeStack(&stack);
    int rowCheck;
    int colCheck;
    Pixel startPixel = {row, column, color};
    char oldColor = tempPicture[row][column];

    push(startPixel, &stack);
    while (isEmpty(stack) == false) {
        pixelCurrent = pop(&stack);
        tempPicture[pixelCurrent.row][pixelCurrent.col] = color;
        int i;
        for ( i = 0; i < 8; i++) {
            //Check left
            if(i == 0){
                rowCheck = 0;
                colCheck = -1;
            }
            //Check right
            if(i == 1){
                rowCheck = 0;
                colCheck = 1;
            }
            //check top
            if(i == 2){
                rowCheck = -1;
                colCheck = 0;
            }
            //check bottom
            if(i == 3){
                rowCheck = 1;
                colCheck = 0;
            }
            //check top left
            if (i == 4) {
                rowCheck = -1;
                colCheck = -1;
            }
            //check top right
            if (i == 5) {
                rowCheck = -1;
                colCheck = 1;
            }
            //check bottom left
            if (i == 6) {
                rowCheck = 1;
                colCheck = -1;
            }
            //check bottom right
            if (i == 7) {
                rowCheck = 1;
                colCheck = 1;
            }
            int newRows = pixelCurrent.row + rowCheck;
            int newColumn = pixelCurrent.col + colCheck;
            //Boundary check for rows
            if (newRows >= 0) {
                if(newRows < numRows){
                    //Boundary check for columns
                    if(newColumn >= 0){
                        if(newColumn < numCols){
                            //Change color
                            if(tempPicture[newRows][newColumn] == oldColor){
                                Pixel pixelNew = {newRows, newColumn, color};
                                push(pixelNew, &stack);
                            }
                        }
                    }
                }
            }
        }
    }
    //Display changed screen
    showPictureOnScreen();
}

int main(int argc, char** argv) {
    readingFilePicture(argv[1]);
    showPictureOnScreen();

    int row;
    int column;
    char color;
    while((row != -1) && (column != -1)) {
        printf("Enter a row: ");
        scanf("%d", &row);
        if (row == -1) break;
        printf("Enter a column: ");
        scanf("%d", &column);
        if (column == -1) break;
        printf("Enter a color: ");
        scanf(" %c", &color);
        changeColor(row, column, color);
    }
    return 0;
}