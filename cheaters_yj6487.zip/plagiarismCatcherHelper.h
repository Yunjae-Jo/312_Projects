//
// Created by yunjae on 8/6/2023.
//

#ifndef PROJECT8_PLAGIARISMCATCHERHELPER_H
#define PROJECT8_PLAGIARISMCATCHERHELPER_H

#include <vector>
#include <iostream>
#include <fstream>
#include <cmath>
#include <set>
#include <unordered_map>
#include <algorithm>

using namespace std;

char changeToLower(char input);

bool checkWhat(char input);

bool checkSpace(char input);

string essayCreate(const string& essay);

set<string> createPWord(const string& essay, int p);

int calculateSimilarity(const set<string>& set1, const set<string>& set2);

#endif //PROJECT8_PLAGIARISMCATCHERHELPER_H
