//
// Created by yunjae on 8/6/2023.
//

#include "plagiarismCatcherHelper.h"

char changeToLower(char input) {
    if (input >= 'A' && input <= 'Z') {
        return input + ('a' - 'A');
    }
    return input;
}

bool checkWhat(char input) {
    return (input >= 'A' && input <= 'Z') || (input >= 'a' && input <= 'z') || (input >= '0' && input <= '9');
}

bool checkSpace(char input) {
    return input == ' ' || input == '\t' || input == '\n' || input == '\r' || input == '\f' || input == '\v';
}

string essayCreate(const string& essay) {
    string preEssay;
    for (char character : essay) {
        // Convert to lowercase
        preEssay += changeToLower(character);
        //removing
        if (checkWhat(character) || character == '\'') {
            preEssay += character;
        }
        else if (checkSpace(character)) {
            preEssay += ' ';
        }
    }
    return preEssay;
}
//p-word
vector<string> splitWords(const string& essay) {
    vector<string> words;
    string word;
    size_t start = 0;
    size_t end = essay.find(' ');
    while (end != string::npos) {
        word = essay.substr(start, end - start);
        if (!word.empty()) {
            words.push_back(word);
        }
        start = end + 1;
        end = essay.find(' ', start);
    }
    word = essay.substr(start);
    if (!word.empty()) {
        words.push_back(word);
    }
    return words;
}
set<string> createPWord(const string& essay, int p) {
    set<string> seq1;
    vector<string> allWords = splitWords(essay);
    for (size_t i = 0; i <= allWords.size() - p; ++i) {
        string seq2;
        for (int j = 0; j < p; ++j) {
            seq2 += allWords[i + j];
            if (j < p - 1) {
                seq2 += " ";
            }
        }
        seq1.insert(seq2);
    }
    return seq1;
}

int calculateSimilarity(const set<string>& set1, const set<string>& set2) {
    int count = 0;
    for (const string& seq : set1) {
        if (set2.count(seq) > 0) {
            count++;
        }
    }
    return count;
}