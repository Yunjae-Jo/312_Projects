Yunjae Jo
yj6487
08/09/2023

PlagiarismCatcher: This program takes input of the directory that contains multiple essays to compare with. The purpose of this program is to detect plagiarism that occurs between the provided essays. It first converts the essays so that it is easier for the program to compare the essays together. First, it converts the essays into lowercase and removes every special character and punctuation except the apostrophe. After that, it creates a word sequence, what we call p-words, for each essay. The program compares the similarity based on the sharing of 
p-word sequences. Each time a similarity is found, it is stored in a matrix. If the similarity exceeds the inputted m-value, then the essays are considered to be plagiarized. There are 2 cpp file and one h file. The plagiarismCatcher.cpp is used as a driver where it runs the main program. The plagirismCatcherHelper.cpp is where the essays a preprocessed, changing uppercase into lowercase, checking whitespaces, creating p-word sequences, calculating the similarities in the essays.

How to run:
1. Unzip the files
2. Copy the files inside the Linux directory that you have created
3. Copy the files that contains the essay that you want to compare inside the Linux directory
4. Check if all the files have been copied into the directory
5. "cd" into the directory
6. Type in "make"
7. Type in ll to check the highlighted word
8. Type in ./highlighted word + the file name of where the essays are at + p value + m value (ex: ./plagiarismCatcher sm_doc_set 6 200)
Potential issues
The output value might not exactly match with the output expected due to the different choice of hash function.