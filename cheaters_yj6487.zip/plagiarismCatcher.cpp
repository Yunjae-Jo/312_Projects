#include <vector>

#include <iostream>
#include <fstream>

#include <dirent.h>
#include <cmath>
#include <set>

#include <unordered_map>
#include <algorithm>

#include "plagiarismCatcherHelper.h"

using namespace std;

int main(int argc, char* argv[]) {
    string dir = argv[1];
    int pValue = atoi(argv[2]);
    int mValue = atoi(argv[3]);
    vector<string> fNames;
    unordered_map<string, string> usingEssay;
    unordered_map<string, set<string>> sequencesForEssay;
    //Read essay
    DIR* dir2 = opendir(dir.c_str());
    struct dirent* first;
    while ((first = readdir(dir2)) != nullptr) {
        if (first->d_type == DT_REG) {
            string fName2 = first->d_name;
            ifstream infile(dir + "/" + fName2);
            if (infile) {
                string line;
                string essayContent;
                while (getline(infile, line)) {
                    essayContent += line + "\n";
                }
                string changedEssay = essayCreate(essayContent);
                usingEssay[fName2] = changedEssay;
                fNames.push_back(fName2);
            }
        }
    }
    closedir(dir2);
    for (const string& fName : fNames) {
        //p-word
        string preEssay = usingEssay[fName];
        set<string> sequences = createPWord(preEssay, pValue);
        sequencesForEssay[fName] = sequences;
    }
    vector<vector<int>> storeSimilar(fNames.size(), vector<int>(fNames.size(), 0));
    for (size_t i = 0; i < fNames.size(); ++i) {
        for (size_t j = i + 1; j < fNames.size(); ++j) {
            const set<string>& sequences1 = sequencesForEssay[fNames[i]];
            const set<string>& sequences2 = sequencesForEssay[fNames[j]];
            int similarityCount = calculateSimilarity(sequences1, sequences2);
            storeSimilar[i][j] = similarityCount;
            storeSimilar[j][i] = similarityCount;
        }
    }
    vector<pair<int, pair<string, string>>> pairSort;
    for (size_t i = 0; i < fNames.size(); i++) {
        for (size_t j = i + 1; j < fNames.size(); j++) {
            if (storeSimilar[i][j] > 0) {
                pairSort.push_back({ storeSimilar[i][j], { fNames[i], fNames[j] } });
            }
        }
    }
    sort(pairSort.rbegin(), pairSort.rend());
    //Pair m
    for (const auto& pairData : pairSort) {
        int counter = pairData.first;
        if (counter > mValue) {
            const string& f1 = pairData.second.first;
            const string& f2 = pairData.second.second;
            cout << counter << ": " << f1 << ", " << f2 << endl;
        }
    }
    return 0;
}
