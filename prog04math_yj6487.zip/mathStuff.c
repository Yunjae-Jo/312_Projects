/* mathStuff_xxxxxx.c

Programmer: Yunjae Jo
EE312  <07/11/2023>

Finish comments here
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

//**********  Function Prototypes  ******************

//function isPrime
//input parameter - positive integer
//returns true if the number is prime, otherwise false
//

bool isPrime (int number);



//function printPrimes
//input parameter - positive integer
//Uses the isPrime method to print a list of prime numbers between 1 and n. 

void printPrimes (int n);


//function findFibo
//input parameter - positive integer
//returns the nth fibonacci number where
//Fib(0) -> 0 
//Fib(1) -> 1 
//Fib(N) -> Fib(N-2) + Fib(N-1)

int findFibo (int n);


//function findFactors
//input parameter - positive integer
//prints the prime factors of the given number to standard output (cout)
//example output: 52=2*2*13 (or 52=1*2*2*13) or 13=prime

void findFactors (int number);


//******************  MAIN  *****************************

int main () {
    
    
    int testNum;
    
    //test for the isPrime function
    printf("Enter a test number - ");
    scanf("%d",&testNum);
    
    if (isPrime(testNum))  
       printf("%d is prime\n",testNum);
    else
       printf("%d is not prime.", testNum);
    
    //test for printing primes
    printf("Enter n to print the prime numbers between 1 and n: ");
    scanf("%d",&testNum);
    
    printPrimes(testNum);
    
    printf("\n");
    
    //test for Fibonacci number finder
    printf("Which Fibonacci number? ");
    scanf("%d",&testNum);
   
    printf("The %d Fibonacci number is : %d \n", testNum, findFibo(testNum)); 
    
    printf("\n");
    
    //test for prime factors
    printf("Factor what number? ");
    scanf("%d",&testNum);
    
    findFactors(testNum);
    
    return 0;
}


//function isPrime
//input parameter - positive integer
//returns true if the number is prime, otherwise false
//
bool helperFuncIsPrime(int number, int dividingNumber){
    //compare the square root for efficiency
    int checkFromSquareRoot = dividingNumber * dividingNumber;
    //For 1
    if(number == 1){
        return false;
    }
    //When the dividing number exceeds the square root of the number
    if(checkFromSquareRoot > number){
        return true;
    }
    //When the dividing number was a factor
    if(number % dividingNumber == 0){
        return false;
    }
    //recursive
    return helperFuncIsPrime(number, dividingNumber + 1);
}

bool isPrime (int number) {
   const int START_DIVISOR = 2; //HINT: You may want a helper function
   return helperFuncIsPrime(number, START_DIVISOR);
}



//function printPrimes
//input parameter - positive integer
//Uses the isPrime method to print a list of prime numbers between 1 and n. 

void helperFuncPrintPrimes(int n, int count){
    //return when count if larger than the input value
    if (count > n){
        return;
    }
    //print the primes
    if (isPrime(count) == true){
        printf("%d ", count);
    }
    //recursive
    helperFuncPrintPrimes(n, count + 1);
}

void printPrimes (int n) {
    helperFuncPrintPrimes(n, 2);
} 



//function findFibo
//input parameter - positive integer
//returns the nth fibonacci number where
//Fib(0) -> 0 
//Fib(1) -> 1 
//Fib(N) -> Fib(N-2) + Fib(N-1)

int findFibo (int n) {
    //fib(0) -> 0
    if(n == 0){
        return 0;
    }
    //fib(1) -> 1
    if(n == 1){
        return 1;
    }
    //equation for fibonacci starting from fib(2)
    return findFibo(n - 2) + findFibo(n - 1);
}

//function findFactors
//input parameter - positive integer
//prints the prime factors of the given number to standard output (cout)
//example output: 52=2*2*13 (or 52=1*2*2*13) or 13=prime


void helperFuncFindFactors(int number, int dividingNumber){
    //return if number is 1
    if(number == 1){
        return;
    }
    //recursive and print
    if(number % dividingNumber == 0){
        //last case
        if(((number / dividingNumber) == 1) == true){
            printf("%d\n", dividingNumber);
        }
        //not last factor so prints out "*"
        else{
            printf("%d*", dividingNumber);
        }
        helperFuncFindFactors(number / dividingNumber, dividingNumber);
    }
    //recursive
    else{
        helperFuncFindFactors(number, dividingNumber + 1);
    }
}
void findFactors (int number)   {
    const int START_DIVISOR = 2;
    printf("%d=", number);
    //when the number is a prime number print "prime"
    if(isPrime(number) == true){
        printf("prime\n");
        return;
    }
    helperFuncFindFactors(number, START_DIVISOR);
}