Yunjae Jo
yj6487
07/12/2023

Math Stuff:
- This program asks the user 4 inputs. First is to enter a number to check if the value is a prime number or not. Second is to enter a number to print the prime numbers between 1 and the input number. Third is to enter a number to print out the nth fibonacci number where n is the input number. Last is to enter a number to factor and print out the prime factors.
How to run:
1. Unzip the files
2. Copy the files inside the Linux directory that you have created
3. Check if all the files have been copied into the directory(including the textfile)
4. "cd" into the directory
5. Type in "make"
6. Type in ll to check the highlighted word
7. Type in ./highlighted word
Potential issues
The user must input the correct input for the rows and columns which is an integer and correct input for the colors which is a single character.