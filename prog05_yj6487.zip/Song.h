//
// Created by yunjae on 7/17/2023.
//
#ifndef SONG_H
#define SONG_H
using namespace std;
#include <string>

class Song{
public:
    Song();
    Song(string artist, string title, int size);
    string getArtist() const;
    string getTitle() const;
    int getSize() const;
    void setArtist(const string& artistSet){
        this->artist = artistSet;
    }
    void setTitle(const string& titleSet){
        this->title = titleSet;
    }
    void setSize(const int& sizeSet){
        this->size = sizeSet;
    }
    bool operator==(const Song& songCompare) const;
    bool operator<(const Song& songCompare) const;
    bool operator>(const Song& songCompare) const;
private:
    string artist;
    string title;
    int size;
};
#endif // SONG_H



