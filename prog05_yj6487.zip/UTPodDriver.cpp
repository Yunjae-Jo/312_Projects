/* UTPod_driver.cpp
Demo Driver for the UTPod.

Roger Priebe
EE 312 10/16/18

This is a basic driver for the UTPod.

You will want to do more complete testing.

*/
#include <cstdlib>
#include <iostream>
#include "Song.h"
#include "UTPod.h"
using namespace std;

int main(){
    UTPod songList;
    int result;

    Song firstSong("Beatles", "Hey Jude1", 4);
    cout << "add result = ";
    result = songList.addSong(firstSong);
    if(result == 0){
        cout << "Add Success" << endl;
    }
    else{
        cout << "Add Failed" << endl;
    }

    cout << "Current List:" << endl;
    songList.showSongList();
    cout << endl;

    Song secondSong("Beatles", "Hey Jude2", 5);
    cout << "add result = ";
    result = songList.addSong(secondSong);
    if(result == 0){
        cout << "Add Success" << endl;
    }
    else{
        cout << "Add Failed" << endl;
    }

    cout << "Current List:" << endl;
    songList.showSongList();
    cout << endl;

    Song thirdSong("Beatles", "Hey Jude3", 6);
    cout << "add result = ";
    result = songList.addSong(thirdSong);
    if(result == 0){
        cout << "Add Success" << endl;
    }
    else{
        cout << "Add Failed" << endl;
    }

    cout << "Current List:" << endl;
    songList.showSongList();
    cout << endl;

    Song fourthSong("Beatles", "Hey Jude4", 7);
    cout << "add result = ";
    result = songList.addSong(fourthSong);
    if(result == 0){
        cout << "Add Success" << endl;
    }
    else{
        cout << "Add Failed" << endl;
    }

    cout << "Current List:" << endl;
    songList.showSongList();
    cout << endl;

    Song fifthSong("Beatles", "Hey Jude5", 241);
    cout << "add result = ";
    result = songList.addSong(fifthSong);
    if(result == 0){
        cout << "Add Success" << endl;
    }
    else{
        cout << "Add Failed" << endl;
    }

    cout << "Current List:" << endl;
    songList.showSongList();
    cout << endl;

    Song sixthSong("Beatles", "Hey Jude5", 300);
    cout << "add result = ";
    result = songList.addSong(sixthSong);
    if(result == 0){
        cout << "Add Success" << endl;
    }
    else{
        cout << "Add Failed" << endl;
    }

    cout << "Current List:" << endl;
    songList.showSongList();
    cout << endl;

    result = songList.removeSong(firstSong);
    if(result == 0){
        cout << "Delete Success" << endl;
    }
    else{
        cout << "Not Found" << endl;
    }

    cout << "Current List:" << endl;
    songList.showSongList();
    cout << endl;

    result = songList.removeSong(firstSong);
    if(result == 0){
        cout << "Delete Success" << endl;
    }
    else{
        cout << "Not Found" << endl;
    }

    cout << "Current List:" << endl;
    songList.showSongList();
    cout << endl;

    cout << "Memory Left= " << songList.getRemainingMemory() << " out of " << songList.getTotalMemory() << endl;
    cout << endl;

    songList.sortSongList();
    cout << "Sorted Song List:" << endl;
    songList.showSongList();
    cout << endl;

    songList.shuffle();
    cout << "Shuffled Song List:" << endl;
    songList.showSongList();
    cout << endl;
}