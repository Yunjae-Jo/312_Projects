//
// Created by yunjae on 7/17/2023.
//
#include "Song.h"

Song::Song(){
    setArtist("NoName");
    setTitle("NoName");
    setSize(0);
}
Song::Song(string artist, string title, int size){
    setArtist(artist);
    setTitle(title);
    setSize(size);
}
string Song::getArtist() const{
    return this->artist;
}
string Song::getTitle() const{
    return this->title;
}
int Song::getSize() const{
    return this->size;
}
bool Song::operator==(const Song& songCompare) const{
    if(artist == songCompare.artist){
        if(title == songCompare.title){
            if(size == songCompare.size){
                return true;
            }
        }
    }
    return false;
}
bool Song::operator<(const Song& songCompare) const{
    if(artist != songCompare.artist){
        if(artist < songCompare.artist){
            return true;
        }
        else{
            return false;
        }
    }
    if(title != songCompare.title){
        if(title < songCompare.title){
            return true;
        }
        else{
            return false;
        }
    }
    if(size < songCompare.size){
        return true;
    }
    else{
        return false;
    }
}
bool Song::operator>(const Song& songCompare) const{
    if(artist != songCompare.artist){
        if(artist > songCompare.artist){
            return true;
        }
        else{
            return false;
        }
    }
    if(title != songCompare.title){
        if(title > songCompare.title){
            return true;
        }
        else{
            return false;
        }
    }
    if(size > songCompare.size){
        return true;
    }
    else{
        return false;
    }
}
