//
// Created by yunjae on 7/17/2023.
//
#include "UTPod.h"
#include <cstdlib>
#include <ctime>
#include <iostream>
using namespace std;

UTPod::UTPod(){
    songs = nullptr;
    memSize = MAX_MEMORY;
    srand(time(0));
}
UTPod::UTPod(int size){
    songs = nullptr;
    if(size > 0){
        if(size <= MAX_MEMORY){
            memSize = size;
        }
    }
    else{
        memSize = MAX_MEMORY;
    }
    srand(time(0));
}
UTPod::~UTPod(){
    clearMemory();
}
int UTPod::addSong(Song const& add){
    if(getRemainingMemory() < add.getSize()){
        return NO_MEMORY;
    }
    SongNode* newNode = new SongNode;
    newNode->s = add;
    newNode->next = songs;
    songs = newNode;
    return SUCCESS;
}
int UTPod::removeSong(Song const& remove){
    SongNode* currentPointer = songs;
    SongNode* previous = nullptr;
    while(currentPointer != nullptr){
        if(currentPointer->s == remove){
            if(previous == nullptr) {
                songs = currentPointer->next;
            }
            else{
                previous->next = currentPointer-> next;
            }
            delete currentPointer;
            return SUCCESS;
        }
        previous = currentPointer;
        currentPointer = currentPointer->next;
    }
    return NOT_FOUND;
}
void UTPod::shuffle(){
    int numSong = 0;
    SongNode* currentPointer = songs;
    //count number of songs
    while(currentPointer != nullptr){
        numSong++;
        currentPointer = currentPointer->next;
    }
    for(int i = 0; i < numSong; i++){
        //from 0 to size - 1
        int pos = rand() % numSong;
        int counter = 0;
        SongNode* change1 = songs;
        while(counter < pos){
            change1 = change1->next;
            counter++;
        }
        SongNode* change2 = songs;
        counter = 0;
        while(counter < i){
            change2 = change2->next;
            counter++;
        }
        // Swap the songs
        Song temp = change1->s;
        change1->s = change2->s;
        change2->s = temp;
    }
}
void UTPod::showSongList(){
    SongNode* currentPointer = songs;
    while(currentPointer != nullptr){
        cout << "Artist: " << currentPointer->s.getArtist() << endl;
        cout << "Title: " << currentPointer->s.getTitle() << endl;
        cout << "Size: " << currentPointer->s.getSize() << " MB" << endl;
        currentPointer = currentPointer->next;
    }
}
void UTPod::sortSongList(){
    SongNode* currentPointer = songs;
    SongNode* nextSong = nullptr;
    while(currentPointer != nullptr){
        nextSong = currentPointer->next;
        while(nextSong != nullptr){
            if(nextSong->s < currentPointer->s){
                // Swap the songs
                Song temp = currentPointer->s;
                currentPointer->s = nextSong->s;
                nextSong->s = temp;
            }
            nextSong = nextSong->next;
        }
        currentPointer = currentPointer->next;
    }
}
void UTPod::clearMemory(){
    SongNode* currentPointer = songs;
    while(currentPointer != nullptr){
        SongNode* nextNode = currentPointer->next;
        delete currentPointer;
        currentPointer = nextNode;
    }
    songs = nullptr;
}
int UTPod::getRemainingMemory(){
    int used = 0;
    SongNode* currentPointer = songs;
    while(currentPointer != nullptr){
        used = used + currentPointer->s.getSize();
        currentPointer = currentPointer->next;
    }
    return memSize - used;
}