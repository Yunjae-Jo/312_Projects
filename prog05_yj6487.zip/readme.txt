Yunjae Jo
yj6487
07/19/2023

UTPod:
- This project creates a UTPod which functions similar to an ipod. The programmer who coded this becomes the user and chooses which song to input before the run. The song also includes the artist and the size of the song. The songs in the UTPod cannot exceed 512MB, which would output failure. The song can be removed from the UTPod but when a song that does not exist is removed it would output failure. There are also features that can randomly shuffle the songs and sort the songs to ascending order. Lastly the user can print out the remaining amount of memory after the adding and removing have been completed.
How to run:
1. Unzip the files
2. Copy the files inside the Linux directory that you have created
3. Check if all the files have been copied into the directory
4. "cd" into the directory
5. Type in "make"
6. Type in ll to check the highlighted word
7. Type in ./highlighted word
Potential issues
The user might exceed 512MB for all of the song resulting in the UTPod to have no songs available.