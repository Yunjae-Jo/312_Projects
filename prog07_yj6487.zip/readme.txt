Yunjae Jo
yj6487
08/02/2023

BST: This code takes in any data type such as string, int, double, char, and even objects to save it into the tree according to 3 different types of traversal. The inorder traversal prints out the data from the left tree to the root to the right tree, the preorder traversal prints out the data from the root first then the left and right subtree, and the postorder traversal prints out the left and right suntree first then prints the root at the last. The delete node deletes the item that the user inputed in the main file.
- 
How to run:
1. Unzip the files
2. Use Clion to open the header file
3. Write the data on a textfile to be on the tree
4. Use a driver file to run the code
5. Check the output
6. Rewrite the text file with a different data type
7. repeat the steps
Potential errors:
By mixing the type of inputs would cause an error.