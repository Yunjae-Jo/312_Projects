#include "stack312_arr.h"
#include <stdbool.h>
//creates the stack
void makeStack(Stack312 *sp){
    sp->top = -1;
}
//checks if the stack is full
bool isFull(Stack312 s){
    return s.top == MAX_ELEMENTS - 1;
}
//checks if the stack is empty
bool isEmpty(Stack312 s){
    return s.top == -1;
}
//push into the stack
void push(StackEntry e,Stack312 *sp){
    if(isFull(*sp) == false) {
        sp->top++;
        sp->elements[sp->top] = e;
    }
}
//pop out of the stack
StackEntry pop(Stack312 *sp){
    if(isEmpty(*sp) == false) {
        StackEntry popChar = sp->elements[sp->top];
        sp->top--;
        return popChar;
    }
    else{
        return '\0';
    }
}