Yunjae Jo
yj6487
06/30/2023

Equation Checker:
- This program takes sets of equations that are both balanced and not balanced. When the equation is balacned it should output the expression and display that it is a valid expression. When the equation is not balanced it outputs the expression and displays the missing bracket. The brackets that can be used are '()', '[]',and '<>'.
How to run:
1. Unzip the files
2. Copy the files inside the Linux directory that you have created
3. Check if all the files have been copied into the directory(including the textfile)
4. "cd" into the directory
5. Type in "make"
6. Type in ll to check the highlighted word
7. Type in ./highlighted word picture_name.txt
Potential issues
The user might type in a bracket that is not specified on the program and not get the result they expected.