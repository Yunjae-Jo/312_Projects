#include <stdio.h>
#include <string.h>
#include "stack312_arr.h"
#define MAX_LENGTH 80

//flip the brackets to show which brackets are missing
char change(char c){
    if(c == ')'){
        return '(';
    }
    if(c == ']'){
        return '[';
    }
    if(c == '>'){
        return '<';
    }
    if(c == '('){
        return ')';
    }
    if(c == '['){
        return ']';
    }
    if(c == '<'){
        return '>';
    }
    else{
        return ' ';
    }
}
//This function checks if the brackets in an expression is balanced or not
void checkBalance(const char *expression) {
    Stack312 stack;
    makeStack(&stack);
    int expLength = strlen(expression);
    for (int i = 0; i < expLength; i++) {
        char currentChar = expression[i];
        if (currentChar == '(' || currentChar == '[' || currentChar == '<') {
            //pushing the open brackets onto the stack
            push(currentChar, &stack);
        }
        //check if the current character stored is a close bracket
        else if (currentChar == ')' || currentChar == ']' || currentChar == '>') {
            //check if there is a problem with the opening brackets
            if (isEmpty(stack) == true) {
                printf("%s === missing %c\n",expression, change(currentChar));
                return;
            }
            //check if there is a problem in the center
            char topChar = pop(&stack);
            if (((topChar == '(' && currentChar == ')') || (topChar == '[' && currentChar == ']') || (topChar == '<' && currentChar == '>')) == false) {
                printf("%s === missing %c\n",expression, change(topChar));
                return;
            }
        }
    }
    //check if there is a problem on the closing brackets
    if (isEmpty(stack) == false) {
        printf("%s === missing %c\n",expression, change(pop(&stack)));
    }
    else {
        printf("%s === valid expression\n", expression);
    }
}
int main(int argc, char *argv[]) {
    char *filename = argv[1];
    FILE *file = fopen(filename, "r");
    char expression[MAX_LENGTH];
    while (fgets(expression, sizeof(expression), file)) {
        //considering the newline for expression
        int len = strlen(expression);
        for (int i = 0; i < len; i++) {
            if (expression[i] == '\r' || expression[i] == '\n') {
                expression[i] = '\0';
                break;
            }
        }
        checkBalance(expression);
    }
    fclose(file);
    return 0;
}
