#include <stdio.h>


char tempPicture[25][25];
int numRows = 0;
int numCols = 0;

//This function reads the text-file given and gets the number of rows and columns
void readingFilePicture(char* fileName) {
    FILE *file = fopen(fileName, "r");
    if (file == NULL) {
        printf("Cannot open file.\n");
        return;
    }
    char colorInPicture;
    int row = 0;
    int column = 0;
    while ((colorInPicture = fgetc(file)) != -1) {
        if (colorInPicture == '\n') {
            column = 0;
            row++;
        }
        else {
            tempPicture[row][column] = colorInPicture;
            column++;
            //Add an if statement since the column becomes 0 after everytime it gets back into the loop
            if (column > numCols) {
                //Get max column
                numCols = column;
            }
        }
    }
    //Get max row
    numRows = row;
    fclose(file);
}
//displays the picture on the screen
void showPictureOnScreen() {
    for (int i = 0; i < numRows; i++)
    {
        for (int j = 0; j < numCols; j++)
        {
            printf("%c", tempPicture[i][j]);
        }
        printf("\n");
    }
}
void changeColor(int row, int column, char color) {
    char oldColor = tempPicture[row][column];
    //Base case
    if (oldColor == color){
        return;
    }
    //Recursive case
    else{
        tempPicture[row][column] = color;
        // Check top
        if(row - 1 >= 0 && tempPicture[row - 1][column] == oldColor){
            changeColor(row - 1, column, color);
        }
        // Check bottom
        if(row + 1 < numRows && tempPicture[row + 1][column] == oldColor){
            changeColor(row + 1, column, color);
        }
        // Check left
        if(column - 1 >= 0 && tempPicture[row][column - 1] == oldColor){
            changeColor(row, column - 1, color);
        }
        // Check right
        if(column + 1 < numCols && tempPicture[row][column + 1] == oldColor){
            changeColor(row, column + 1, color);
        }
        // Check top left
        if(row - 1 >= 0 && column - 1 >= 0 && tempPicture[row - 1][column - 1] == oldColor){
            changeColor(row - 1, column - 1, color);
        }
        // Check top right
        if(row - 1 >= 0 && column + 1 < numCols && tempPicture[row - 1][column + 1] == oldColor){
            changeColor(row - 1, column + 1, color);
        }
        // Check bottom left
        if(row + 1 < numRows && column - 1 >= 0 && tempPicture[row + 1][column - 1] == oldColor){
            changeColor(row + 1, column - 1, color);
        }
        // Check bottom right
        if(row + 1 < numRows && column + 1 < numCols && tempPicture[row + 1][column + 1] == oldColor){
            changeColor(row + 1, column + 1, color);
        }
    }
}


int main(int argc, char** argv) {
    readingFilePicture(argv[1]);
    showPictureOnScreen();

    int row = 0;
    int column = 0;
    char color;
    while((row != -1) && (column != -1)){
        printf("Enter a row: ");
        scanf("%d", &row);
        if (row == -1) break;
        printf("Enter a column: ");
        scanf("%d", &column);
        if (column == -1) break;
        printf("Enter a color: ");
        scanf(" %c", &color);
        changeColor(row, column, color);
        showPictureOnScreen();
    }
    return 0;
}