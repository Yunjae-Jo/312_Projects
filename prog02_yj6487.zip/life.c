#include "life.h"
#include <stdio.h>
#include <stdlib.h>

void populateWorld(char fname[], char *grid[], int *numRows, int *numCols) {
    FILE* file;
    char strTmp[80];
    char charTmp;
    //make file what is in the text file
    file = fopen(fname, "r");
    if(file == NULL) {
        printf("Error opening file");
    }
    *numCols = 0;
    charTmp = fgetc(file);
    //until the end of the column
    while ((charTmp != '\n')){
        *numCols+=1;
        charTmp = fgetc(file);
    }
    printf("Number of columns = %d\n",*numCols);
    rewind(file);
    *numRows = 0;
    while (fgets(strTmp, *numCols+2, file) != NULL) {
        //malloc for grid
        grid[*numRows] = (char *) malloc((*numCols + 1) * (sizeof(char)));
        for (int i = 0; i < *numCols; i++) {
            grid[*numRows][i] = strTmp[i];
        }
        //null terminate
        grid[*numRows][*numCols] = '\0';
        //increment value in the address numRow by 1
        (*numRows)++;
    }
    printf("Number of rows = %d\n",*numRows);
    fclose(file);
    return;
}

    void showWorld(char *grid[], int numRows, int numCols) {
        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numCols; j++) {
                if (grid[i][j] == '1') {
                    printf("*");
                } else {
                    printf(".");
                }
            }
            //used to write on the next row
            printf("\n");
        }
    }

    void iterateGeneration(char *grid[], int numRows, int numCols) {
        //make a temporary array to store the next generation
        char nextGen[numRows][numCols];
        int neighborLive = 0;
        //what row the targeting cell is
        for (int i = 0; i < numRows; i++) {
            //what column the targeting cell is
            for (int j = 0; j < numCols; j++) {
                //from -1 to 1 since it is the range of neighbor cell for a column
                for (int moveY = -1; moveY <= 1; moveY++) {
                    //from -1 to 1 since it is the range of neighbor cell for a row
                    for (int moveX = -1; moveX <= 1; moveX++) {
                        //doesn't consider the target cell a neighboring cell
                        if (moveX != 0 || moveY != 0) {
                            //adding the range in the targeting cell's row and column
                            int currentX = i + moveY;
                            int currentY = j + moveX;
                            //four boundary
                            if ((currentX >= 0) && (currentX < numRows) && (currentY >= 0) && (currentY < numCols)){
                                //checkin the state of neighboring cell
                                if(grid[currentX][currentY] == '1'){
                                    neighborLive++;
                                }
                            }


                        }
                    }
                }
                //checking the number of neighboring cell
                if (grid[i][j] == '1') {
                    if (neighborLive < 2 || neighborLive > 3) {
                        nextGen[i][j] = '0';
                    } else {
                        nextGen[i][j] = '1';
                    }
                } else {
                    if (neighborLive == 3) {
                        nextGen[i][j] = '1';
                    } else {
                        nextGen[i][j] = '0';
                    }
                }
                neighborLive = 0;
            }
        }
        //Taking the temporary array that has the updated generation into the original array
        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numCols; j++) {
                grid[i][j] = nextGen[i][j];
            }
        }
    }


