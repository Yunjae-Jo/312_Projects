// life.h
// -- EE 312 Project 2

/* Student information for project:
 *
 * Replace <NAME> with your name.
 *
 * On my honor, Yunjae Jo, this programming project is my own work
 * and I have not provided this code to any other student.
 *
 * Name: Yunjae Jo
 * email address: yunjae@utexas.edu
 * UTEID: yj6487
 * Section 5 digit ID: 75590
 *
 *///
// Created by priebe on 9/5/2018.
//

#ifndef UNTITLED1_LIFE_H
#define UNTITLED1_LIFE_H

#endif //UNTITLED1_LIFE_H

//This function takes in the text-file and updates it into the grid by determining the number of rows and columns
void populateWorld(char fname[], char *grid[], int *numRows, int *numCols);

//This function is used to print the grid on to the screen. It takes in the 0s and 1s and changes it to *s and .s
void showWorld(char *grid[], int numRows, int numCols);

//This function is used to update the next generation based on the given rules it updates the given grid
void iterateGeneration(char *grid[], int numRows, int numCols);
